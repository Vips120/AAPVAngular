export interface Iproduct {
    name:string;
    price:number;
    imgUrl:string;
    rating:number;
}