export class TemplateUser{
    public username:string;
    public password:string;
    public email:string;
}