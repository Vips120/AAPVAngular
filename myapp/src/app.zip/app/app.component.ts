import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  cardImg = '../assets/img/2.jpg';
  title = 'vipul';
  totalLikes = 10;
}
