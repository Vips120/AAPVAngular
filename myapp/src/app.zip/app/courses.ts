export class CourseDetail {
    getCourse():Array<string>{
  return ["Angular", "javascript", "Typescript", "Nodejs"];
    }
     getMobileDevice():Array<string>{
         return ["LG", "MI", "Oneplus", "Nokia"];
     }

}